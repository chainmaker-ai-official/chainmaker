/**
 * Menu data structure and categories for ActivityPopupMenu
 * This is the large static data object extracted from the component
 */

import { useMemo } from 'react';

/**
 * Categories for the activity menu
 */
export const categories = [
  { id: 'data-provider', name: 'Data Provider', icon: '📊', type: 'category' },
  { id: 'strategy', name: 'Strategy', icon: '⚖️', type: 'category' },
  { id: 'risk-management', name: 'Risk Management', icon: '🛡️', type: 'category' },
  { id: 'alpha-generation', name: 'Alpha Generation', icon: '📖', type: 'category' },
  { id: 'ai-enhanced', name: 'AI-Enhanced', icon: '🤖', type: 'category' },
  { id: 'execution', name: 'Execution', icon: '⚔️', type: 'category' },
  { id: 'dashboard', name: 'Dashboard', icon: '📈', type: 'category' },
  { id: 'ai-native', name: 'AI-Native', icon: '💬', type: 'category' },
  { id: 'marketplace-more', name: 'Add more from marketplace', icon: '🛒', type: 'action' }
];

/**
 * Activities by category - loaded from bc-activities.json
 */
export const activitiesByCategory = {
  'data-provider': [
    { id: 'live-order-book', name: 'Live Order Book Table', icon: '📊', type: 'activity' },
    { id: 'transaction-unjumble', name: 'Transaction Unjumble (Decompiler)', icon: '🧩', type: 'activity' },
    { id: 'geyser-plugin', name: 'Geyser Plugin Integration', icon: '👀', type: 'activity' },
    { id: 'block-proposer', name: 'Block Proposer Monitor', icon: '🔮', type: 'activity' },
    { id: 'cross-chain-bridge', name: 'Cross-Chain Bridge Monitor', icon: '🌉', type: 'activity' }
  ],
  'strategy': [
    { id: 'arbitrage-comparison', name: 'Arbitrage Comparison Module', icon: '⚖️', type: 'activity' },
    { id: 'sandwich-attack', name: 'Sandwich Attack Logic', icon: '🥪', type: 'activity' },
    { id: 'volatility-scalper', name: 'Volatility Scalper', icon: '⚡', type: 'activity' }
  ],
  'risk-management': [
    { id: 'binary-risk-gate', name: 'Binary Risk Gate', icon: '🛡️', type: 'activity' },
    { id: 'tokenomics-parser', name: 'Tokenomics Parser', icon: '📊🔍', type: 'activity' },
    { id: 'balance-protection', name: 'Balance Protection Guard', icon: '🛑', type: 'activity' },
    { id: 'simulation-engine', name: 'Simulation Engine', icon: '🧪', type: 'activity' },
    { id: 'flash-loan-protector', name: 'Flash Loan Protector', icon: '🚨', type: 'activity' }
  ],
  'alpha-generation': [
    { id: 'social-sentiment', name: 'Social Sentiment Reading Module', icon: '📖', type: 'activity' },
    { id: 'dex-pool-factory', name: 'DEX Pool Factory Tracker', icon: '🏊', type: 'activity' },
    { id: 'liquidity-migration', name: 'Liquidity Migration Tracker', icon: '🏄', type: 'activity' }
  ],
  'ai-enhanced': [
    { id: 'ai-signal-engine', name: 'AI-Powered Signal Engine', icon: '🤖', type: 'activity' }
  ],
  'execution': [
    { id: 'priority-fee-gas-war', name: 'Priority Fee Gas War Battles', icon: '⚔️', type: 'activity' },
    { id: 'jito-bundle-signer', name: 'Jito-Solana Bundle Signer', icon: '📦', type: 'activity' },
    { id: 'smart-order-router', name: 'Smart Order Router (SOR)', icon: '🛣️', type: 'activity' },
    { id: 'nonce-manager', name: 'Nonce Manager / Transaction Queue', icon: '📑', type: 'activity' }
  ],
  'dashboard': [
    { id: 'visual-graph-analytics', name: 'Visual Graph Analytics', icon: '📈', type: 'activity' },
    { id: 'data-view', name: 'Data View', icon: '📊', type: 'activity' }
  ],
  'ai-native': [
    { id: 'ai-telegram-trading', name: 'AI Telegram Trading Partner', icon: '💬', type: 'activity' }
  ]
};

/**
 * Hook to generate menu data with injected activities from Redux store
 * @param {array} addedActivities - Activities added to palette from Redux
 * @returns {object} - Menu data structure
 */
export const useMenuData = (addedActivities) => {
  return useMemo(() => {
    const baseMenu = {
      root: {
        id: 'root',
        title: 'Categories',
        items: categories
      }
    };

    // Add submenus for each category
    categories.forEach(category => {
      if (category.type === 'category' && activitiesByCategory[category.id]) {
        baseMenu[category.id] = {
          id: category.id,
          title: category.name,
          items: activitiesByCategory[category.id]
        };
      }
    });

    // Inject items from the Redux store
    addedActivities.forEach(activity => {
      const categoryId = activity.category.toLowerCase().replace(/\s+/g, '-');
      if (baseMenu[categoryId]) {
        const alreadyExists = baseMenu[categoryId].items.some(item => item.id === `market-${activity.id}`);
        if (!alreadyExists) {
          baseMenu[categoryId].items.push({
            id: `market-${activity.id}`,
            name: activity.title,
            icon: activity.icon,
            type: 'activity'
          });
        }
      }
    });

    return baseMenu;
  }, [addedActivities]);
};

/**
 * Hook to filter menu data based on search query
 * @param {object} menuData - The full menu data object
 * @param {string} searchQuery - The search query string
 * @returns {object} - Filtered menu data
 */
export const useFilteredMenuData = (menuData, searchQuery) => {
  return useMemo(() => {
    if (!searchQuery.trim()) return menuData;

    const query = searchQuery.toLowerCase().trim();
    const filtered = {};

    // Filter root items
    const rootItems = menuData.root.items.filter(item => 
      item.name.toLowerCase().includes(query) ||
      (menuData[item.id] && menuData[item.id].items.some(subItem => 
        subItem.name.toLowerCase().includes(query)
      ))
    );

    filtered.root = { ...menuData.root, items: rootItems };

    // Filter submenus
    rootItems.forEach(item => {
      if (menuData[item.id]) {
        const subItems = menuData[item.id].items.filter(subItem =>
          subItem.name.toLowerCase().includes(query)
        );
        filtered[item.id] = { ...menuData[item.id], items: subItems };
      }
    });

    return filtered;
  }, [menuData, searchQuery]);
};

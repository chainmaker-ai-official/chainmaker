/**
 * Utility functions for activity lookup and status checking
 */
import activitiesData from '../../../../assets/activities.json';
import bcActivitiesData from '../../../../assets/bc-activities.json';

/**
 * Get activity object by menu item ID
 * @param {string} menuItemId - The menu item ID
 * @param {object} activityIdMap - Mapping of menu item IDs to activity IDs
 * @param {array} marketplaceActivities - List of activities from marketplace
 * @returns {object|null} - Activity object or null if not found
 */
export const getActivityByMenuItemId = (menuItemId, activityIdMap, marketplaceActivities) => {
  const activityId = activityIdMap[menuItemId];
  if (!activityId) return null;
  
  // First look in marketplaceActivities (from activities.json)
  let activity = marketplaceActivities.find(activity => activity.id === activityId);
  
  // If not found, look in bc-activities.json data (blockchain activities)
  if (!activity && bcActivitiesData && bcActivitiesData.trading_modules) {
    activity = bcActivitiesData.trading_modules.find(activity => activity.id === activityId);
  }
  
  // If not found, look in activities.json data
  if (!activity && activitiesData && activitiesData.activities) {
    activity = activitiesData.activities.find(activity => activity.id === activityId);
  }
  
  return activity;
};

/**
 * Check if an activity is already added to the palette
 * @param {string} menuItemId - The menu item ID
 * @param {object} activityIdMap - Mapping of menu item IDs to activity IDs
 * @param {array} marketplaceActivities - List of activities from marketplace
 * @param {array} addedActivities - List of already added activities
 * @returns {boolean} - True if activity is already added
 */
export const isActivityAdded = (menuItemId, activityIdMap, marketplaceActivities, addedActivities) => {
  const activity = getActivityByMenuItemId(menuItemId, activityIdMap, marketplaceActivities);
  if (!activity) return false;
  return addedActivities.some(a => a.id === activity.id);
};
